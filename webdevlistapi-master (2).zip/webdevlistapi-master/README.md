1. Composer install  ( to maintain dependencies b/w OS and php version )
	Download it from here ( https://getcomposer.org/download/ )

2. Xampp or Wamp required.
3. Clone code from git repo
4. Composer update
5. Create .env file by copy same code from .env.example and edit db name in .env
6. Create DB on your server with same name as that in .env file
7. Open cmd in project's folder
8. Run command (php artisan migrate) 
9. Execute command in cmd - php artisan serve
10. Open chrome and run code on http://127.0.0.1:8000